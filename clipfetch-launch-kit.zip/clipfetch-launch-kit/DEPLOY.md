# Free hosting: GitHub Pages

This is a static website, so it can be hosted without paying for a server.

1. Sign in to GitHub and create a repository named `clipfetch`.
2. Upload `index.html` to the repository root.
3. Open repository **Settings → Pages**.
4. Select **Deploy from a branch**.
5. Choose `main` and `/(root)`, then save.
6. GitHub will show the public website address after deployment.

You must perform the account sign-in and repository creation yourself. Do not share your password or verification codes in chat.

Alternative: import the GitHub repository into Netlify or Vercel and use their static-site deployment flow. Check each provider's current free-plan limits before launch.
