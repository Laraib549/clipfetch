# ClipFetch backend plan (safe and permission-based)

## Important reality
There is no universal, reliable, policy-compliant endpoint that downloads every YouTube, Instagram, Facebook, TikTok, X, and Pinterest post from a pasted public URL. Platform APIs, copyright rules, login controls, and download permissions differ. A social post URL is not a direct media URL.

Do not implement scraping of private content, login/session-cookie collection, DRM bypass, or circumvention of platform restrictions.

## Recommended architecture
- Frontend: the included static `index.html`.
- Backend: Node.js (Fastify or Express) only when a permitted workflow needs server-side processing.
- Storage: avoid storing user videos by default; if storage is necessary, set short retention and deletion controls.
- Security: HTTPS, request-size limits, rate limits, URL allowlists where possible, strict timeouts, abuse logging with minimal personal data, and no user-supplied server-side fetches without SSRF protections.

## Supported workflow types
1. Direct media URL: allow only a direct file URL from a host the user is authorized to access. Validate host and file type; do not blindly fetch arbitrary URLs from the server.
2. Creator-owned content: link to the platform's official creator download/export workflow where available.
3. Official APIs: integrate only documented APIs and permitted scopes. Some APIs provide metadata or embeds, not downloadable media bytes.
4. User uploads: let users upload files they own, then provide permitted conversion or processing.

## Suggested API contract
- `POST /api/inspect-link`
  - Input: `{ "url": "https://..." }`
  - Output: `{ "kind": "direct_media|social_post|unsupported", "message": "..." }`
  - Must validate URL syntax and reject localhost, private IP ranges, unusual schemes, and unsupported hosts.
- `POST /api/process-upload`
  - Accepts user-uploaded media only, enforces size/type limits, and checks that processing is allowed.
- `GET /health`
  - Returns service health only.

## Launch sequence
1. Publish the static frontend first (GitHub Pages / Netlify / Vercel).
2. Confirm the site works on phone and desktop.
3. Decide which official/authorized platform integrations are actually available.
4. Add backend only for those confirmed workflows.
5. Add privacy policy, terms, takedown/contact process, rate limiting, and monitoring before public use.
