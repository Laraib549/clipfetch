# ClipFetch launch kit

## Included
- `index.html`: responsive front-end starter.
- `DEPLOY.md`: free static-hosting instructions.
- `BACKEND_PLAN.md`: safe backend architecture and integration boundaries.

## What is working now
The page validates URLs and recognizes direct video-file links. It does not download media from social-platform post URLs.

## Publish free with GitHub Pages
1. Create/sign in to a GitHub account.
2. Create a new **public** repository named `clipfetch`.
3. Upload `index.html`, `DEPLOY.md`, and `BACKEND_PLAN.md` to the repository root.
4. Open **Settings → Pages**.
5. Under Build and deployment, choose **Deploy from a branch**.
6. Select branch `main` and folder `/ (root)`, then Save.
7. Wait for GitHub Pages to publish and open the URL shown on that page.

You can also deploy the folder by importing the repository into Netlify or Vercel. Free-plan terms and availability can change.

## Before public launch
Add a privacy policy, terms of use, abuse/contact process, rate limiting (if a backend is added), and clear copyright/permission guidance.
